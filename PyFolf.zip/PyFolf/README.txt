
*************************
****** PyFolf v1.0 ******
*************************

Pyfolf is written by Evan Thatcher using Python version 2.5.2

Compiled for binary distribution using py2exe

It is distributed under the GNU General Public License Version 3



To play the game double click on the PyFolf executable

For game play instructions consult "How To Play.txt"

For insturctions on building your own course consult "Course Design Tutorial.txt"